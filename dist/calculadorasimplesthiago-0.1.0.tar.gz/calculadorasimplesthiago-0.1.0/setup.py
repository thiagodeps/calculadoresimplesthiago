from setuptools import find_packages, setup

setup(
    name='calculadorasimplesthiago',
    packages=find_packages(),
    version='0.1.0',
    description='calculadora para atividade projetos de sistemas',
    author='Eu',
    license='MIT',
)